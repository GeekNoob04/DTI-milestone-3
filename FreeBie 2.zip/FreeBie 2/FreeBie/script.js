// Wait for the DOM content to be fully loaded
document.addEventListener("DOMContentLoaded", function() {
    // Get the buttons and input field
    const emailInput = document.querySelector('input[type="text"]');
    const getStartedBtn = document.querySelector('.hero-buttons .btn');
    const faqBoxes = document.querySelectorAll('.faqbox');

    // Add event listener to the Get Started button
    getStartedBtn.addEventListener('click', function(event) {
        event.preventDefault(); // Prevent default form submission behavior

        const email = emailInput.value.trim(); // Get the value of the input field and remove leading/trailing spaces

        // Check if the email is valid (a simple check, not a comprehensive validation)
        if (validateEmail(email)) {
            alert(`Thank you for signing up with email: ${email}`);
        } else {
            alert('Please enter a valid email address.');
        }
    });

    // Add event listener to the FAQ boxes for toggling visibility
    faqBoxes.forEach(box => {
        box.addEventListener('click', function() {
            this.classList.toggle('expanded'); // Toggle the 'expanded' class
        });
    });

    // Function to validate email using a simple regex pattern
    function validateEmail(email) {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailPattern.test(email);
    }
});
