<?php
session_start();

// Generate a random CAPTCHA code
$captchaCode = rand(1000, 9999);

// Store the CAPTCHA code in the session
$_SESSION['captcha'] = $captchaCode;

// Debug output
echo "CAPTCHA code: $captchaCode";

// Set the content type header to display the image
// header('Content-Type: image/png');

// Create an image with specified dimensions
// $image = imagecreatetruecolor(100, 40);

// Set background color
// $bgColor = imagecolorallocate($image, 255, 255, 255);
// imagefill($image, 0, 0, $bgColor);

// Set text color
// $textColor = imagecolorallocate($image, 0, 0, 0);

// Write the CAPTCHA code on the image
// imagestring($image, 5, 25, 10, $captchaCode, $textColor);

// Output the image as PNG
// imagepng($image);

// Destroy the image to free up memory
// imagedestroy($image);
?>
